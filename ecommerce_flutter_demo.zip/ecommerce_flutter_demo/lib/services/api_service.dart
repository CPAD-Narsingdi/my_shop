import 'package:ecommerce_flutter_demo/model/product.dart';
import 'package:http/http.dart' as http;

class ApiService {
  static var apiClient = http.Client();

  static Future<List<Product>> fetchProducts() async {
    var response = await apiClient.get('https://jsonplaceholder.typicode.com/photos');
    if (response.statusCode == 200) {
      var jsonString=response.body;
      return productFromJson(jsonString);
    } else {
      //handle error
      return null;
    }
  }
}
