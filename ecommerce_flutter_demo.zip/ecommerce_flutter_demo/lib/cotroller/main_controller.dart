import 'package:ecommerce_flutter_demo/model/product.dart';
import 'package:ecommerce_flutter_demo/services/api_service.dart';
import 'package:get/state_manager.dart';

class MainController extends GetxController{
  var productList=List<Product>().obs;
  var isLoaading=true.obs;

  @override
  void onInit() async {
    isLoaading(true);
    productList.assignAll(await ApiService.fetchProducts());
    isLoaading(false);
    // getProducts();
    super.onInit();
  }

  // void getProducts() async{
  //   var products=await ApiService.fetchProducts();
  //   if(products!=null){
  //     productList.assignAll(products);
  //   }
  // }

}