package com.example.ecommerce_flutter_demo

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
